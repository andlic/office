TARGETS = mountkernfs.sh hostname.sh x11-common mountdevsubfs.sh procps hwclock.sh checkroot.sh networking urandom bootmisc.sh mountall-bootclean.sh mountall.sh mountnfs-bootclean.sh mountnfs.sh checkfs.sh checkroot-bootclean.sh
INTERACTIVE = checkroot.sh checkfs.sh
mountdevsubfs.sh: mountkernfs.sh
procps: mountkernfs.sh
hwclock.sh: mountdevsubfs.sh
checkroot.sh: hwclock.sh mountdevsubfs.sh hostname.sh
networking: mountkernfs.sh urandom procps
urandom: hwclock.sh
bootmisc.sh: mountall-bootclean.sh mountnfs-bootclean.sh checkroot-bootclean.sh
mountall-bootclean.sh: mountall.sh
mountall.sh: checkfs.sh checkroot-bootclean.sh
mountnfs-bootclean.sh: mountnfs.sh
mountnfs.sh: networking
checkfs.sh: checkroot.sh
checkroot-bootclean.sh: checkroot.sh
